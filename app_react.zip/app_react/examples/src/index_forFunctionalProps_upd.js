import React from 'react';
import ReactDOM from 'react-dom';
import { render} from 'react-dom';
import {
	BrowserRouter as Router,Switch,Route,Link
} from 'react-router-dom';
import MyComponent from '../../src/index_fun_props_1.js';
<script src="https://cdnjs.cloudflare.com/ajax/libs/mathjs/7.0.1/math.min.js"></script>



ReactDOM.render(
    <Router>
        <MyComponent />
    </Router>, 
    document.getElementById('root')
)

{/*const SPA = () => (
    <App />
);
render(<MyComponent />, document.getElementById("root"));*/}