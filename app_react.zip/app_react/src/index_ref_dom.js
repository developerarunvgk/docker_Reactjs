import React from 'react';
import ReactDOM from 'react-dom';

import {
	BrowserRouter as Router,Switch,Route,Link
} from 'react-router-dom';
import Home from './home.js'
import Contact from './contact'
import About from './about'
import axios from 'axios';


class App extends React.Component {
	constructor(){
		super()
		this.state={name:"arun",
		data1:[],
		persons:[]
	};
	              this.Getrest = this.Getrest.bind(this);
	          {/* Inside arrow function of getrest, this became undefined */}
                this.GetFocusRef = this.GetFocusRef.bind(this);

	}

    GetFocusRef(){
            ReactDOM.findDOMNode(this.refs.myInput).focus();
            var a=ReactDOM.findDOMNode(this.refs.myInput);
            console.log(a);
            console.log("In Reference");
    }

    Getrest(){
    	console.log("Inside Get Rest");
    	axios.get(`https://jsonplaceholder.typicode.com/users`)
        .then(res => {
        const persons = res.data;
        alert(this)
        alert(res.data)
        console.log(res.data)
        this.setState({data1:persons});
      })


    }

   render() {
    return(

    	<Router>
      <div>
      <button onClick={this.Getrest}>Click Rest Axio</button>
      <button onClick={this.GetFocusRef} ref = "myInput">Click Reference Button</button>

      <ul>
      <li><Link to="/">Home</Link></li>
      <li><Link to="/home">Home</Link></li>
      <li><Link to="/about">About</Link></li>
      <li><Link to="/contact">Contact</Link></li>
      </ul>

      {this.props.children}
  	  {/*  No validity */}

  	        <ul>
        { this.state.data1.map((person) => <li key={person.id}>{person.name}</li>)}
	      </ul>

      </div>


      <Switch>
      <Route exact path="/">
      	<Home/>
      </Route>

      <Route path="/about">
      	<About/>
      </Route>
      <Route path="/home">
      	<Home/>
      </Route>
      <Route path="/contact">
      	<Contact/>
      </Route>

      	
      </Switch>
      </Router>

    )
  }
}
export default App;



