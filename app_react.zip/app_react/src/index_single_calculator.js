import React from 'react';
import PropTypes from 'prop-types';
import './styles.css';
import ReactDOM from 'react-dom';
import * as math from "mathjs";
import xtype from 'xtypejs'

//const MyComponent = () => (
//    <h1>Hello from Arun Venu Functional</h1>
//);

class MyComponent extends React.Component {
	constructor(){
		super();
		this.state={
			motto:"Let Noble thoughts come from all sides",
			ins:"0",
			rs:"0",
			inpd:"0"
		}
	this.Upyog = this.Upyog.bind(this);

	}
	Upyog(event){
//		alert('In Upgrog');
	//	alert(event.target.value);
		//console.log(xtype(event.target.value));
		//console.log(xtype(this.state.ins));
		var a=event.target.value + "+" + this.state.ins;
		//alert(a)
		this.setState({inpd:a});
		var count2=eval(a);

	//	alert("Result : "+a+ " is " + count2.toString());
		this.setState({ins:count2.toString()});
		this.setState({rs:count2.toString()});

	};
   render() {
	   	var i=1
      var sty={
      	color:'blue',
      	fontSize:34,
      	marginLeft:129
      }
      return (
         <div>
            <h1 style={{color:"orange"}}>{this.state.motto}</h1>
            <Button labelica={1} addHan={this.Upyog}/>
            <Button labelica={2} addHan={this.Upyog}/>
            <Button labelica={3} addHan={this.Upyog}/>
            <br></br>
            <Button labelica={4} addHan={this.Upyog}/>
            <Button labelica={5} addHan={this.Upyog}/>
            <Button labelica={6} addHan={this.Upyog}/>
            <br></br>
            <Button labelica={7} addHan={this.Upyog}/>
            <Button labelica={8} addHan={this.Upyog}/>
            <Button labelica={9} addHan={this.Upyog}/>
             <br></br>
            <Button labelica={0} addHan={this.Upyog}/>
            <Button labelica="+" />
            <Button labelica="=" />
            <br></br>
            <Screenin inpds={this.state.inpd}></Screenin>
                        <br></br>

            <Screenrs rss={this.state.rs}></Screenrs>
         </div>
      );
   }
}


class Button extends React.Component{
	render(){
		return (
			<button type="button" onClick={this.props.addHan} value={this.props.labelica} >{this.props.labelica} </button>
			);
	}
}
class Screenin extends React.Component{
	render(){
		return(
		<input type="text" id="fnalme" name="fnalme" readOnly value={this.props.inpds}/>
		);
	}
}


class Screenrs extends React.Component{
	render(){
		return(
		<input type="text" readOnly value={this.props.rss}/>
		);
	}
}


export default MyComponent;