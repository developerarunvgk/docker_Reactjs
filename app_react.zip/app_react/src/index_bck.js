import React from 'react';
import PropTypes from 'prop-types';
import './styles.css';
import ReactDOM from 'react-dom';

//const MyComponent = () => (
//    <h1>Hello from Arun Venu Functional</h1>
//);


class MyComponent extends React.Component {
	constructor(){
		super();
		this.state={
			data:
			[
				{
				"id":1,
				"name":"Rajini",
				"Job":"Python_Developer"
				},
				{
				"id":2,
				"name":"Surya",
				"Job":"ShareMarket"
				},
				{
				"id":3,
				"name":"Sachin",
				"Job":"Sleep"
				}
			],
			motto:"Let Noble thoughts come from all sides"
		}
	}







   render() {
   	var i=1
      var sty={
      	color:'blue',
      	fontSize:34,
      	marginLeft:129
      }
      return (
         <div>
            <h1 style={{color:"orange"}}>{this.state.motto}</h1>
            <ul>
            <li> Arun </li>
            <li> RaviKumar </li>
            </ul>
            {0+1}<p id={'qwe'} style={{color: 'red'}} data-myattribute = "somevalue">This is the news content!!!</p>
            {1+1}<p style={sty} data-myattribute = "somevalue">This is the paid news content!!!</p>
                        <h1> {i==1? 'OkTrue' : 'OkPaid'} </h1>
                        <ListElection data1={this.state.motto} />
                <table>
               <tbody>
                  {this.state.data.map((lml, i) => <Tablerowa key = {i} 
                     data = {lml} />)}
               </tbody>

            </table>
            <Button color={"red"} funct={"Changecolor"}/>

         </div>
      );
   }
}


class ListElection extends React.Component{
	constructor(){
		super();
		this.state={
			motto:"Indian by Birth"
		}
	}
	render(){
		var styl={
			color:'red'
		}	
	return(
	<div>
				<h2>{this.state.motto}</h2>

			<h2>{this.props.data1}</h2>
			<h3>String: {this.props.data1}</h3>

			Election Commission og Infia
            <ul>
            <li style={{color:'green'}}> Kerala </li>
            <li> Tamil </li>
            </ul>

	</div>

	);
	}
}
ListElection.propTypes = {
  data1: PropTypes.string
};


class Tablerowa extends React.Component{
	render(){
		var styl={
			color:'red'
		}
	
	return(
			<tr style={styl}>
			<td>{this.props.data.id}</td>
			<td>{this.props.data.name}</td>
			<td>{this.props.data.Job}</td>
	</tr>

	);
	}
}

class Button extends React.Component{
	constructor(props){  
		super(props);
		this.state={
			color:'blue',
			data2:[],
			functionname:this.props.funct
		}
		      this.DataAddition = this.DataAddition.bind(this);
              this.Changecolor = this.Changecolor.bind(this);

	}
	Changecolor()
	{
	  var myDiv = document.getElementById('qwe');
      ReactDOM.findDOMNode(qwe).style.color = 'FF8000';

	};

	DataAddition()
	{
		var arritem='love';
	    document.getElementById("qwe").innerHTML = "Namo Namo Namo";
		var arr=this.state.data2.slice();
		    arr.push(arritem);
		    alert('Love is added')
		this.setState({data2:arr})
	};
	render(){
		var styl={
			color:'cyan',
			marginLeft:45
		}
	
	return(
		<div>
			<button style={styl} onClick={this.DataAddition}> Click me </button>
			<button style={styl} onClick={this.Changecolor}> Colour Change </button>

			<h2>{this.state.color}</h2>
				<h2 style={styl}>{this.props.color}</h2>
				<h2>{this.state.data2}</h2>

		</div>
	);
	}
}




export default MyComponent;