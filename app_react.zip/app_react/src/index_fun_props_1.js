import React from 'react';
import PropTypes from 'prop-types';
import './styles.css';
import ReactDOM from 'react-dom';

//const MyComponent = () => (
//    <h1>Hello from Arun Venu Functional</h1>
//);

function MyComponent(){
let hime = (l) => {
	    alert(l + ' from child button is clicked or called');
  	{/*alert(this);*/}
  };
	return(
	<div>
	    <h1>Hello from Arun Venu Functional2</h1>
	    <Welcome name="David Billa" zar={hime} />{/*
	Passing function name of parent to child and calling it via props.zar on onclick
	WHile calling use zar(int) to get the value

	    */}
	    <Welcome name="Billa" zar={hime}/>
	    <Desc lml="Election Mania"/>
	</div>
	);
}

function Welcome({name,zar}){
{/*function Welcome(props) is replaced by props name ka values. Can use directly now Else we need to use props.zar etc*/}
    let hi = (e) => {
	    alert(e + ' button is clicked');
  };

	  let hello = (e) => {
    alert('Hello PMK');
    alert(e + ' button is clicked');

  };

  let sendMessage = (e) =>{
  	alert(e.target.value);
  	{/*alert(this);*/}

  	zar(10);


{  	/*
  	Calling parent Function  from child Welcome
  	*/
 }

  };

  function hello1(e){
  	alert('Hello h1');
  };

	return(
		<div>
		<h1 onClick={hi} value="Love">Hi {name}</h1>
		    <button value="Arun" onClick={sendMessage}>      Send message </button>
 <button value="Gopika" onClick={sendMessage}>  IBS  </button>

		</div>
		);
}


const Desc = (props) =>(
<h1 style={{color:"blue"}}>Hello from  Venu Functional in {props.lml}</h1>
);









class MyComponentc extends React.Component {
	constructor(){
		super();
		this.state={
			data:
			[
				{
				"id":1,
				"name":"Rajini",
				"Job":"Python_Developer"
				},
				{
				"id":2,
				"name":"Surya",
				"Job":"ShareMarket"
				},
				{
				"id":3,
				"name":"Sachin",
				"Job":"Sleep"
				}
			],
			motto:"Let Noble thoughts come from all sides"
		}
		              this.DataAddition1p = this.DataAddition1p.bind(this);
		              this.DataAddition1 = this.DataAddition1.bind(this);


	}
	DataAddition1()
	{
	    document.getElementById("qwe").innerHTML = "Namo Namo - Jai Ho";
	    console.log("Ram");
		console.log(this);
		{/* 
			this is called successfully via react : No issues [Given it is binded].
			But when Bind is removed , this is producing null.
			Applicable to event onClick etc.
			Not Applicable if calling function is an arrow function (:1)

			In object instance calling scenario, context that calls is an object and this will yield value
			onClick in React pass reference to function, so react needs binding to find it unless it is arrow  
			or instead of passing reference, call the function directly in onClick

			eg:Tested in  Button by removing
			   this.Stateparty = this.Stateparty.bind(this);
			   onClick="this.Stateparty()"
			   It gave Button for this in console.log(this);

		*/}

	};

	DataAddition1p(par1)
	{
	    document.getElementById("qwe").innerHTML = "Namo Namo - Jai Hind";
	    alert(par1);
		
		{/*this.DataAddition1();*}

		{/* This is needed for it to work.
		Even in absence of bind for DataAddition1,it works because it takes its context*/}

	};






   render() {
   	var i=1
      var sty={
      	color:'blue',
      	fontSize:34,
      	marginLeft:129
      }
      return (
         <div>
            <h1 style={{color:"orange"}}>{this.state.motto}</h1>
            <ul>
            <li> Arun </li>
            <li> RaviKumar </li>
            </ul>
            {0+1}<p id={'qwe'} style={{color: 'red'}} data-myattribute = "somevalue">This is the news content!!!</p>
            {1+1}<p style={sty} data-myattribute = "somevalue">This is the paid news content!!!</p>
                        <h1> {i==1? 'OkTrue' : 'OkPaid'} </h1>
                        <ListElection data1={this.state.motto} />
                <table>
               <tbody>
                  {this.state.data.map((lml, i) => <Tablerowa key = {i} 
                     data = {lml} />)}
               </tbody>

            </table>
            <Button color={"red"} funct={"Changecolor"} zar={this.DataAddition1} zarp={this.DataAddition1p}/>

         </div>
      );
   }
}


class ListElection extends React.Component{
	constructor(){
		super();
		this.state={
			motto:"Indian by Birth"
		}
	}
	render(){
		var styl={
			color:'red'
		}	
	return(
	<div>
				<h2>{this.state.motto}</h2>

			<h2>{this.props.data1}</h2>
			<h3>String: {this.props.data1}</h3>

			Election Commission og Infia
            <ul>
            <li style={{color:'green'}}> Kerala </li>
            <li> Tamil </li>
            </ul>

	</div>

	);
	}
}
ListElection.propTypes = {
  data1: PropTypes.string
};


class Tablerowa extends React.Component{
	render(){
		var styl={
			color:'red'
		}
	
	return(
			<tr style={styl}>
			<td>{this.props.data.id}</td>
			<td>{this.props.data.name}</td>
			<td>{this.props.data.Job}</td>
	</tr>

	);
	}
}



class Button extends React.Component{
	constructor(props){  
		super(props);
		this.state={
			count1:0,
			color:'blue',
			data2:[],
			functionname:this.props.funct
		}
		      this.DataAddition = this.DataAddition.bind(this);
              this.Changecolor = this.Changecolor.bind(this);
              this.Counterraj = this.Counterraj.bind(this);
              this.Cpcall = this.Cpcall.bind(this);
              this.Stateparty = this.Stateparty.bind(this);


	}
	Counterraj()
	{
		var count2=this.state.count1 + 1;
		this.setState({count1:count2});
		if (count2>=10){
			alert('It Ten here.Pls dont increase');
		}
	}

	Stateparty()
	{
 			this.setState({data2:[]});
 			alert('Love Div is cleared : All in all');
 			console.log(this);
	};

	Cpcall()
	{
 			this.setState({data2:[]});
 			alert('Love Div is cleared : All in all');
 			this.props.zarp('Indian');

	};


	Changecolor()
	{
	  var myDiv = document.getElementById('qwe');
      ReactDOM.findDOMNode(qwe).style.color = 'FF8000';

	};

	DataAddition()
	{
		var arritem='love';
	    document.getElementById("qwe").innerHTML = "Namo Namo Namo";
		var arr=this.state.data2.slice();
		    arr.push(arritem);
		    alert('Love is added')
		this.setState({data2:arr})
	};
	render(){
		var styl={
			color:this.props.color,
			marginLeft:45
		}
	
	return(
		<div>
			<h2>Players here is {this.state.count1}</h2>
			<button id={this.props.color} style={styl} onClick={this.DataAddition}> Click me </button>
			<button id={this.state.color} style={styl} onClick={this.Changecolor}> Colour Change </button>
			<button id={this.state.color} style={styl} onClick={this.props.zar}> Click me via Props </button>
			<button id={this.state.color} style={styl} onClick={this.Stateparty}> Clear Data in it </button>
			<button id={this.state.color} style={styl} onClick={this.Counterraj}> Incrementor Value </button>
			<button id={this.state.color} style={styl} onClick={this.Cpcall}> Click me via Props Param via state </button>

			<h2>{this.state.color}</h2>
				<h2 style={styl}>{this.props.color}</h2>
				<h2>{this.state.data2}</h2>
				<h2 style={styl}>{this.state.color}</h2>


		</div>
	);
	}
}
export default MyComponent;