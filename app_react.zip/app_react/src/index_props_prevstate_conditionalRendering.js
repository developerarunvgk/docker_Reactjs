import regeneratorRuntime from "regenerator-runtime";
import React from 'react';
import ReactDOM from 'react-dom';

import {
	BrowserRouter as Router,Switch,Route,Link
} from 'react-router-dom';
import Home from './home.js'
import Contact from './contact'
import About from './about'
import axios from 'axios';


let skiData={
  total:10,
  name:"Raja",
  age:44,
  code:"Aja"
}

class App extends React.Component {
	constructor(){
		super()
		this.state={name:"arun",
		data1:[],
		persons:[],
    ipw:"",
    vol:"blue",
    sty:"hidden",
    ipin:"yahoo.com",
    open:true,
    count:0
	};
	              this.Getrest = this.Getrest.bind(this);
	          {/* Inside arrow function of getrest, this became undefined */}
                this.GetFocusRef = this.GetFocusRef.bind(this);
                this.Togg=this.Togg.bind(this);

	}
    SayWelcome(){
      console.log("Welcome My Arun")
    }
    Togg(){
      console.log("Changing");
      this.setState((prevstate) => ({ count: prevstate.count + 1, vol:"red",open:!prevstate.open}));
      {/* use this.prevstate to access previous state value*/}
    }

    async GetFocusRef(){
            ReactDOM.findDOMNode(this.refs.myInputweb).focus();
            var a=ReactDOM.findDOMNode(this.refs.myInputweb);
            {/*ReactDOM.findDOMNode(this.refs.lml).focus();
            var a=ReactDOM.findDOMNode(this.refs.lml); ===>Point to last li element in axios,if axios is not called,It resuult in Error
            */}
            //console.log(a);
            //console.log(a.value);
            console.log("In Reference");
            //this.setState({ipin:a.value},() => console.log(this.state.ipin));
            await this.setState({ ipin: a.value,sty:"visible" });
            console.log(this.state.ipin + " is from GetFocus ");
            //return a.value;

    }

    async Getrest(){
      this.SayWelcome();
      console.log("Inside Get Rest");
      await this.GetFocusRef();
      //console.log(site1)
      console.log("All Parameters Fetched")
      var apiname="http://127.0.0.1:8000/jip?website=";
      var site=this.state.ipin;
      console.log(site);
      var req12=apiname+site;
      console.log(req12);

      axios.get(req12)
        .then(res => {
        const persons = res.data;
       // alert(this)
       // alert(res.data)
        console.log(res.data);
        console.log(res.data.ip);
        this.setState({ipw:res.data.ip});
      })
      

    }

   render() {
   	      var styl={
      	color:' #ff9933',
      	fontSize:41,
      	marginLeft:23,
      	visibility:this.state.sty
      }

    return(

    	<Router>
      <div>
      <h2 style={{color:"#009933"}}>IP finder using Django/React</h2>
      <input type="text" name="webin" ref = "myInputweb" placeholder="Enter Name of Website"/>
      <br></br>
      <button onClick={this.Getrest}>Find ip of Website(Click Rest Axio Django)</button>
      <h4 style={{color:this.state.vol}}> Availability : {this.state.open? 'Yes' : 'No'}</h4> {/*Cannot use this.prevstate*/}
       <button onClick={(prevstate) => {console.log("jai ram");console.log(this.state.open);this.setState({open:false}); } } >Switch Off Inline Ananymous</button>
       <button onClick={this.Togg} >Switch Off prev</button>
       <h4>{this.state.count}</h4>

       <Butto name="Button123" age="123" code={skiData.code}></Butto>
      <ul style={{display:"none"}}>
      <li><Link to="/">Home</Link></li>
      <li><Link to="/home">Home</Link></li>
      <li><Link to="/about">About</Link></li>
      <li><Link to="/contact">Contact</Link></li>
      </ul>

      {this.props.children}
  	  {/*  No validity */}
  	  	
        <h4 id={this.state.sty} style={styl} > <span style={{color:"#cc33ff"}}> {this.state.ipw} </span>  is the ip of website {this.state.ipin}</h4>
  	        <ul>
        {/* this.state.data1.map((person) => <li ref="lml" key={person.id}>{person.name}</li>)*/}
	      </ul>

      </div>


      <Switch>
      <Route exact path="/">
      	<Home/>
      </Route>

      <Route path="/about">
      	<About/>
      </Route>
      <Route path="/home">
      	<Home/>
      </Route>
      <Route path="/contact">
      	<Contact/>
      </Route>

      	
      </Switch>
      </Router>

    )
  }
}
export default App;



class Butto extends React.Component {
  constructor(props){
    super(props);
    this.state={
      name:this.props.name,
      pp:this.props
    }
                this.dtl = this.dtl.bind(this);

  }
  dtl(){
    console.log("Butto");
    console.log(this.state.name);
  }
  render(){
  const {name,age,code}=this.props
  console.log("It will not work here and constructor")
    return(
    <div>
    <h4>{name}</h4>
    <h4>{age}</h4>
    <h4>{this.props.code}</h4>
    <button onClick={this.dtl}>Click me </button>
    </div>
    )
  }
}