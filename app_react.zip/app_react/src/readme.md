React.JS 
-------------------
1.Class based React Component
You can check most files.==> Indexday2.js

2.Function based React Component
You can check most files.==> Index_h.js


3.State and Props and its basic calling
Button Element and App element in indexday2.js

4.Calling Parent Function using props from Child Element
this.props.zar in button in indexday2.js

5.Calling Parent Function with parameter using props from Child Element
this.Cpcall and that function calling zar props of parent inside it [Element is button] ==> index_day3morning.js

6.Calling Child Function using state
this.Cpcall will tell the state calling activity

7.Passing value from Parent to Child using props and state
this.props.color in Button , value passed from app Parent ==> index_day3Morning.js
 <Screenin inpds={this.state.inpd}></Screenin> is called from calculator main class and it updates it.
 When app updates inpd, it reflected religiously in Screen Component == index_single_calculator.js

8.Updating State value from Element based on click
Increment metheod in button

9.Modifying CSS and other properties of child by using props of parent
this.props.color in style in button ==> index_day3morning.js

10.npm start and npm run build==> Command itself is enough

12.Calling Parent Function with parameter using props from Child Element in Function Based Component
sendMessage function and that function calling zar props of parent inside it [Element is button] ==> index_day3morning.js


11.Commenting in reactjs
 /**/ in enclosed curly braces


-------------------------------------------------------

12.This in react statement  [ Day4Series]
------------------------------------------
In class component metheod,
this points to instance of class.
To use this in functions , we need to bind it.
Else it should be arrow [Defintion should be arrow. In short it should be defined where it is called]
Additional Detail
------------------
1.onClick=send(this); in send(arg),this object is printed ,ie calling one even after removing bind.
2.onClick={()=>this.Stateparty(this) & onClick={()=>this.Stateparty() works fine.
2.if data1function has no binding, and prints  this . then it will not work.
But datafunction which has binding calling data1function , then this of data1function works.


In function based methoed,
There is no scope for this, as there is no object in it
Also this from event handlers is disabled due to special nature of react compared to class

In event like Onclick,
There Both above observation works.

13.LifeCycleHooks
-------------------------------
Triggered when some event happens
it is available in class only
No need of Binding with this
Also it is called automatically

----Refer TintuVlogger youtube and index_lifecyclehooks

14.SPA or React_Router
---------------------------------
.SPA is created using react_router.
.Dont refer TutorialPoint.(its wrong)
.ReferTintuVlogger or Mediums one [Bookmarked]
.Careful while importing and exporting
.Include all needed packages

15.Axios
---------------------------------------
.Get Axios is implemented
.Response is an arrow function, and also this is used.
So better include bind for the function
.Result Json is mapped.
.While mapping inorder nor to get Warning, include a key variable in element

16.Reff
---------------------------------------------------
To get DOM or button details,we pass reff
Check Index Ref_dom

Notes
------
Phase1   : LifeHookIndex and Before SPA
Phase2   : SPAV1,SPAV2,Axios_Reffv21

17.Django React Integration
-------------------------------------------------------
1.It is simple.Simply run both application after setting Axios to Django Url and ensure that JSON response is sent
2.CORS Issue may be there, for that in django pip3 install cors
  																Refer DjangoReactv3,V2
18.Async await to ensure setUpdate works 
-----------------------------------------------
1.To ensure setUpdate is updated, use async and await.
2.Else the async function is run without latest value.
3.React Rendering problem may come.
4.Import a keyword as in react files to ensure it works fine. Refer DjangoReactv3,V2


19.Imporved UI
-------------------------
1.Style based on condition
2.Style from setState
3.Async,Await based Setup
4.Improved UI and headings in main html.
Backup of HTML : Before DjangoReactzip
Backup of src : index_async_await,Index_backupbeforefinal




