import regeneratorRuntime from "regenerator-runtime";
import React from 'react';
import ReactDOM from 'react-dom';

import {
	BrowserRouter as Router,Switch,Route,Link
} from 'react-router-dom';
import Home from './home.js'
import Contact from './contact'
import About from './about'
import axios from 'axios';


class App extends React.Component {
	constructor(){
		super()
		this.state={name:"arun",
		data1:[],
		persons:[],
    ipw:"",
    sty:"hidden",
    ipin:"yahoo.com"
	};
	              this.Getrest = this.Getrest.bind(this);
	          {/* Inside arrow function of getrest, this became undefined */}
                this.GetFocusRef = this.GetFocusRef.bind(this);

	}
    SayWelcome(){
      console.log("Welcome My Arun")
    }
    async GetFocusRef(){
            ReactDOM.findDOMNode(this.refs.myInputweb).focus();
            var a=ReactDOM.findDOMNode(this.refs.myInputweb);
            {/*ReactDOM.findDOMNode(this.refs.lml).focus();
            var a=ReactDOM.findDOMNode(this.refs.lml); ===>Point to last li element in axios,if axios is not called,It resuult in Error
            */}
            //console.log(a);
            //console.log(a.value);
            console.log("In Reference");
            //this.setState({ipin:a.value},() => console.log(this.state.ipin));
            await this.setState({ ipin: a.value,sty:"visible" });
            console.log(this.state.ipin + " is from GetFocus ");
            //return a.value;

    }

    async Getrest(){
      this.SayWelcome();
      console.log("Inside Get Rest");
      await this.GetFocusRef();
      //console.log(site1)
      console.log("All Parameters Fetched")
      var apiname="http://127.0.0.1:8000/jip?website=";
      var site=this.state.ipin;
      console.log(site);
      var req12=apiname+site;
      console.log(req12);

      axios.get(req12)
        .then(res => {
        const persons = res.data;
       // alert(this)
       // alert(res.data)
        console.log(res.data);
        console.log(res.data.ip);
        this.setState({ipw:res.data.ip});
      })
      

    }

   render() {
   	      var styl={
      	color:'red',
      	fontSize:41,
      	marginLeft:23,
      	visibility:this.state.sty
      }

    return(

    	<Router>
      <div>
      <input type="text" name="webin" ref = "myInputweb"/>
      <br></br>
      <button onClick={this.Getrest}>Click Rest Axio Django</button>
      <button onClick={this.GetFocusRef} ref = "myInput">Click Reference Button</button>

      <ul style={{display:"none"}}>
      <li><Link to="/">Home</Link></li>
      <li><Link to="/home">Home</Link></li>
      <li><Link to="/about">About</Link></li>
      <li><Link to="/contact">Contact</Link></li>
      </ul>

      {this.props.children}
  	  {/*  No validity */}
  	  	
        <h4 id={this.state.sty} style={styl} >{this.state.ipw} is the ip of website {this.state.ipin}</h4>
  	        <ul>
        {/* this.state.data1.map((person) => <li ref="lml" key={person.id}>{person.name}</li>)*/}
	      </ul>

      </div>


      <Switch>
      <Route exact path="/">
      	<Home/>
      </Route>

      <Route path="/about">
      	<About/>
      </Route>
      <Route path="/home">
      	<Home/>
      </Route>
      <Route path="/contact">
      	<Contact/>
      </Route>

      	
      </Switch>
      </Router>

    )
  }
}
export default App;



