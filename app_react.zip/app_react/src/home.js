import React from 'react';



class Home  extends React.Component {
	render()
	{ return(<div>
		<h4>Find ip of Websites</h4>
		</div>);
		
	}

}

export default Home;
