import React from 'react';



class About  extends React.Component {
	render()
	{ return(<div>
		<h2>Welcome to About</h2>
		</div>);
		
	}

}

export default About;
